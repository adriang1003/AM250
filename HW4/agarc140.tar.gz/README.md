`Run command`: Type `make all` to create executables `hellompi.ex`, `sendReceive.ex`, `pingPong.ex`,
`latency.ex`, `ring.ex`, and `pi.ex`. Type `sbatch hellompi.cmd`, `sbatch sendReceive.cmd`, `sbatch pingPing.cmd`,
`sbatch latency.cmd`, `sbatch ring.cmd`, and `sbatch pi.cmd` to run executables.

See all `*.out` files for sample outputs of each executable.
