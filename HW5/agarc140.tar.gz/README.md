`Run command`: Type `gfortran -fopenmp helloomp.f90 -o helloomp.ex`, `gfortran -fopenmp matmulomp_a.f90 -o matmulomp_a.ex`, and `gfortran -fopenmp matmulomp_b.f90 -o matmulomp_b.ex` to create executables.
Type `sbatch helloomp.cmd`, `sbatch matmulomp_a.cmd`, and `sbatch matmulomp_b.cmd` to run executables.

See all `*.out` files for sample outputs of each executable.
